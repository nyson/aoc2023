from dataclasses import dataclass
from enum import Enum
from io import TextIOWrapper
from itertools import groupby

rank: dict[str, int] = {
	"A": 13,
	"K": 12,
	"Q": 11,
	"J": 10,
	"T": 9,
	"9": 8,
	"8": 7,
	"7": 6,
	"6": 5,
	"5": 4,
	"4": 3,
	"3": 2,
	"2": 1
}

class HandType(Enum):
	FiveOfAKind = 7
	FourOfAKind = 6
	FullHouse = 5
	ThreeOfAKind = 4
	TwoPair = 3
	Pair = 2
	Regular = 1

def hand_type(hand: str) -> HandType:
	match [(key, len(list(group))) for key, group in groupby(sorted(hand))]:
		case _:
			print(f"Unhandled case {hand}")

def parse_hands(file: TextIOWrapper):
	while True:
		match file.readline().split():
			case [""]:
				break
			case lexs:
				print(f"Unhandled case: {lexs}")

def run(file: TextIOWrapper):
	parse_hands(file)